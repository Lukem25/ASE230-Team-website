<?php
// Team members data array
$team = array(
    array(
        "name" => "John Doe",
        "role" => "Lead Developer",
        "dob" => "2000-08-02",  
        "image" => "assets/images/profile.jpg"
    ),
    array(
        "name" => "Jane Smith",
        "role" => "UI/UX Designer",
        "dob" => "1990-09-20",  
        "image" => "assets/images/profile.jpg"
    ),
    array(
        "name" => "Michael Lee",
        "role" => "Backend Engineer",
        "dob" => "1992-03-10",  
        "image" => "assets/images/profile.jpg"
    ),
    array(
        "name" => "Mason Luke",
        "role" => "Cybersecurity Analyst",
        "dob" => "2002-08-02",  
        "image" => "assets/images/Mason.jpg"
    )
);

// Function to calculate age
function calculate_age($dob) {
    $dob = new DateTime($dob);
    $now = new DateTime();
    $age = $now->diff($dob);
    return $age->y;
}

// Function to display member card
function display_member_card($member, $index) {
    echo "<div class='col-md-4'>";
    echo "<div class='card'>";
    echo "<img class='card-img-top' src='" . $member['image'] . "' alt='" . $member['name'] . "'>";
    echo "<div class='card-body'>";
    echo "<h5 class='card-title'>" . $member['name'] . "</h5>";
    echo "<p class='card-text'>Role: " . $member['role'] . "</p>";
    echo "<p class='card-text'>Age: " . calculate_age($member['dob']) . "</p>";
    echo "<a href='detail.php?index=" . $index . "' class='btn btn-primary'>View Details</a>";
    echo "</div></div></div>";
}
?>
<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>Our Amazing Team</title>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Our team profiles">
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
    <script defer src="assets/fontawesome/js/all.min.js"></script>
    <link id="theme-style" rel="stylesheet" href="assets/css/pillar-1.css">
</head> 

<body>    
    <div class="container">
        <h1 class="text-center">OUR AMAZING TEAM</h1>
        <div class="row justify-content-center">
            <!-- Team Members -->
            <?php 
            foreach ($team as $index => $member) {
                display_member_card($member, $index);
            } 
            ?>
        </div>
    </div>
</body>
</html>